import java.util.*;

public class STC extends Object
{
    String type;
    String value;

    public STC(String itype, String ivalue)
    {
	type = itype;
	value = ivalue;
    }
}
